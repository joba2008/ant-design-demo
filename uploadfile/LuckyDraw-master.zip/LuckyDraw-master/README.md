# LuckyDraw
SME Lucky Draw app source code.

WPF desktop application.

请到如下网址查看详细介绍：
http://zzuwzj.github.io/LuckyDraw/
