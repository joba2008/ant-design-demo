/* To apply this animation to your website, paste the following into your HTML code:
<iframe src="https://codepen.io/tommyho/full/BaGPzdK" width=500 height=500></iframe>
*/

/*
  Sources:
  Revised by: tommyho510@gmail.com   
*/

/* --- System Parameters (Recommended)--- */

let scene, camera, renderer;

function degrees_to_radians(degrees) {
  var pi = Math.PI;
  return degrees * (pi / 180);
}

function init() {
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
  );

  scene.lookAt(0, 0.1, 0);

  renderer = new THREE.WebGLRenderer({
    alpha: true
  });

  renderer.setSize(window.innerWidth, window.innerHeight);
  document.getElementById("canvas").appendChild(renderer.domElement);

  const geometryT = new THREE.TorusGeometry(
   9, 1, 10, 36, 2 * Math.PI,
  );

  const geometryS = new THREE.SphereGeometry(
    5, 20, 20
  );
  
  const materialL = new THREE.LineBasicMaterial({
    color: 0xffff00,
    wireframe: true
  });
  
  const materialP = new THREE.PointsMaterial({
    color: 0xffff00, 
    size: 0.3,
    sizeAttenuation: true,
  });  
    
  const materialM = new THREE.MeshBasicMaterial({
    color: 0xffff00, //this sets the color of the particles
    size: 0.2, // this controls the size of the particles
    sizeAttenuation: false,
    wireframe: true,
  });
  
  /*
  const torus = new THREE.LineSegments(geometryT, materialL);
  const sphere = new THREE.Mesh(geometryS, materialM);
  */ 

  const torus = new THREE.Points(geometryT, materialP);
  scene.add(torus);
    
  const sphere = new THREE.Points(geometryS, materialP);
  scene.add(sphere); 

  camera.position.z = 15;
}

function rotateScene() {
  scene.rotation.x += Math.PI / 300;
  scene.rotation.y += Math.PI / 400;
  // scene.rotation.x = Math.PI / 4;
  // scene.rotation.y = Math.PI / 4;
  // scene.rotation.z = Math.PI / 4;
  // scene.rotateX(degrees_to_radians(0.3));
  // scene.rotateY(degrees_to_radians(0.8));
  // scene.rotateZ(degrees_to_radians(0.3));
}

function animate() {
  requestAnimationFrame(animate);
  rotateScene();
  renderer.render(scene, camera);
}

init();
animate();